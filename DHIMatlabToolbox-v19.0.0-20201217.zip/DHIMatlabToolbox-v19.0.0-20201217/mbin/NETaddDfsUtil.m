function H = NETaddDfsUtil(dfsAssemblyName)
    DfsUtilAss = NETaddAssembly('MatlabDfsUtil.dll');
H = DfsUtilAss;
