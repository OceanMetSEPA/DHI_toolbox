asmdfs = NET.addAssembly('DHI.Generic.MikeZero.DFS');
asmeum = NET.addAssembly('DHI.Generic.MikeZero.EUM');
asmdhi = NETaddDfsUtil();
