% @DFS
%
% Files
%   DFS               - DFS/DFS Create new DFS object.
%   display           - DFS/DISPLAY Command window display of DFS file.
%   get               - DFS/GET Get DFS properties.
