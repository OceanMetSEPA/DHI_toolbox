This folder contains source code and build script for the 
MatlabDfsUtil library. 

With these files you can rebuild the MatlabDfsUtil.dll
in case it fails. It also shows how to extend and add further
functionality to the MatlabDfsUtil, and it can also work as a 
template for building a complete other library.

There is a MatlabDfsUtilBuild.bat which will build a new version
of the MatlabDfsUtil.dll. Please update the path of the 
csc.exe (Microsoft C# compiler)

