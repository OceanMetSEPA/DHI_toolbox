close all;

clear all; disp('running: read_dfs0            '); read_dfs0
clear all; disp('running: read_dfs1            '); read_dfs1
clear all; disp('running: read_dfs2            '); read_dfs2
clear all; disp('running: read_dfs2b           '); read_dfs2b
clear all; disp('running: read_dfs3            '); read_dfs3
clear all; disp('running: read_dfsu_2D         '); read_dfsu_2D
clear all; disp('running: read_dfsu_3D         '); read_dfsu_3D
clear all; disp('running: read_res11           '); read_res11
clear all; disp('running: read_Network         '); read_Network
clear all; disp('running: create_dfs0          '); create_dfs0
clear all; disp('running: create_dfs1          '); create_dfs1
clear all; disp('running: create_dfs1_noneqspat'); create_dfs1_noneqspat
clear all; disp('running: create_dfs2          '); create_dfs2
clear all; disp('running: create_dfs3          '); create_dfs3
clear all; disp('running: create_dfsu_2D       '); create_dfsu_2D
clear all; disp('running: create_dfsu_3Dfrom3D '); create_dfsu_3Dfrom3D
clear all; disp('running: write_dfs1           '); write_dfs1
clear all; disp('running: write_dfs2           '); write_dfs2
clear all; disp('running: write_dfsu_2D        '); write_dfsu_2D
